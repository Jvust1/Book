# 第二章　习题

<!-- source_pdf_page: 77; printed_page: 70; exercises begin after §4 continuation -->

### 1

设 \(X\) 是内积空间，\(x,y\in X\) 都是非零元，试证明：

1. 如果 \(x\) 与 \(y\) 正交，则 \(x\) 与 \(y\) 线性无关；

<!-- source_pdf_page: 78; printed_page: 71 -->

2. \(x\) 与 \(y\) 正交的充要条件是对任意数 \(\alpha\)，
   $$
   \|x+\alpha y\|=\|x-\alpha y\|;
   $$
3. \(x\) 与 \(y\) 正交的充要条件是对任意数 \(\alpha\)，
   $$
   \|x+\alpha y\|\ge\|x\|.
   $$

### 2

设 \(\{e_n\}_{n=1}^{\infty}\) 是内积空间 \(X\) 中的正规正交集，则对任意 \(x,y\in X\)，

$$
\sum_{n=1}^{\infty}|(x,e_n)(y,e_n)|
\le\|x\|\,\|y\|.
$$

### 3

设 \(\{e_n\}_{n=1}^{\infty}\) 是 Hilbert 空间 \(H\) 中的正规正交集，

$$
x=\sum_{n=1}^{\infty}\alpha_n e_n,
\qquad
 y=\sum_{n=1}^{\infty}\beta_n e_n.
$$

试证明

$$
(x,y)=\sum_{n=1}^{\infty}\alpha_n\overline{\beta_n},
$$

且右端级数绝对收敛。

### 4

设 \(\{e_n\}_{n=1}^{\infty}\) 是可分 Hilbert 空间 \(H\) 的正规正交基。证明：任给 \(x,y\in H\)，

$$
(x,y)
=
\sum_{n=1}^{\infty}(x,e_n)\overline{(y,e_n)},
$$

且右端级数绝对收敛。

### 5

设 \(D\) 是 \(\mathbb R^n\) 中一个区域。令 \(L^2(D)\) 表示所有的 \(D\) 上平方可积的复值函数 \(f(x)\) 按逐点定义的加法和数乘形成的线性空间，设

$$
(f,g)=\int_D f(x)\overline{g(x)}\,dx,
\qquad f,g\in L^2(D).
$$

试证明：\(L^2(D)\) 按如上定义的内积是一个 Hilbert 空间。

### 6

证明：\(\ell^p\,(p\ne2)\) 不可能是内积空间。

### 7

设 \(\{u_n\}\) 是线性无关的，验证按 Schmidt 正规正交法（2.1）得到的集 \(\{v_n\}\) 是正规正交集。

### 8

证明射影定理（定理 3.1）中的唯一性。

### 9

设 \(M\) 是 Hilbert 空间 \(H\) 的一个线性流形。证明：

1. \(M^\perp\) 是 \(H\) 的子空间；
2. \((\overline M)^\perp=M^\perp\)；
3. 如果 \(M_1\) 也是 \(H\) 的线性流形，使 \(M\subset M_1\)，则 \(M_1^\perp\subset M^\perp\)。

### 10

试证明 \(H^*\) 按如下范数：

$$
\|f\|
=
\sup_{\|x\|\le1}|f(x)|,
\qquad f\in H^*,
$$

是完备的赋范线性空间。

### 11

证明：对任意的 \(x\in H\)，

<!-- source_pdf_page: 79; printed_page: 72 -->

$$
\|x\|
=
\sup_{\|y\|\le1}|(x,y)|.
$$

### 12

验证定理 3.3 中的 \(A\) 是 \(H\) 上有界线性算子。

### 13

设 \(\{e_n\}_{n=1}^{\infty}\) 是 Hilbert 空间 \(H\) 中一个正规正交集。如果对每个 \(x\in H\)，

$$
\|x\|^2
=
\sum_{n=1}^{\infty}|(x,e_n)|^2,
$$

称 \(\{e_n\}_{n=1}^{\infty}\) 是完备的。

设 \(\{e_n\}_{n=1}^{\infty}\)，\(\{f_n\}_{n=1}^{\infty}\) 是 \(H\) 中的两个正规正交集，适合

$$
\sum_{n=1}^{\infty}\|e_n-f_n\|^2<1.
$$

试证明：\(\{e_n\}_{n=1}^{\infty}\) 是完备的当且仅当 \(\{f_n\}_{n=1}^{\infty}\) 是完备的。

### 14

设 \(T\) 是从 Hilbert 空间 \(H_1\) 到 \(H_2\) 的有界线性算子，证明 \(T^*\) 是从 \(H_2\) 到 \(H_1\) 的有界线性算子。

### 15

设 \(T\) 是 Hilbert 空间 \(H\) 上有界线性算子。试证明：若对一切 \(x\in H\)，

$$
\operatorname{Re}(Tx,x)=0,
$$

则

$$
T+T^*=0.
$$

### 16

设 \(T\) 是 \(\ell^2\) 上的有界线性算子：

$$
T:x=(\xi_1,\xi_2,\cdots,\xi_n,\cdots)
\longmapsto
Tx=(\eta_1,\eta_2,\cdots,\eta_n,\cdots),
$$

其中

$$
\eta_n=\sum_{k=1}^{\infty}a_{nk}\xi_k,
\qquad n=1,2,\cdots.
$$

又设 \(T^*\) 是 \(T\) 的伴随算子：

$$
T^*:x=(\xi_1,\xi_2,\cdots,\xi_n,\cdots)
\longmapsto
T^*x=(\eta_1^*,\eta_2^*,\cdots,\eta_n^*,\cdots),
$$

而且

$$
\eta_n^*=\sum_{k=1}^{\infty}a_{nk}^*\xi_k,
\qquad n=1,2,\cdots.
$$

试证明：

$$
a_{nk}^*=\overline{a_{kn}},
\qquad n,k=1,2,\cdots.
$$
